const empModel = require('./models');
const joi = require('joi');
    
const getEmployees = async(req,res) => {
    try {

const employees = await Promise.all(empModel.find({}).exec());

if(employees){
return res.status(201).json({
    object:"list",
    data: employees,
    message:' employees fetched successfully...',
    success:true
});
}
return res.status(404).json({
message: 'employees not found ',
success:false
});
    }
    catch(err){
        return res.status(500).json({
            message:err.message,
            success:false
        })
    }
}

var schema = joi.object({
    _id: joi.string().required(),
    name:joi.string().required(),
    salary:joi.string().required(),
    location:joi.string().required()
})

const createEmployee = async (req,res) => {
    return new Promise((resolve,reject) => {
        try{
const empData =
{
    _id:req.body.id,
    name:req.body.name,
    salary:req.body.salary,
    location:req.body.location
}
 schema.validate(empData);
   const employee = new Employee(empData);
        const emp  = await employee.save();
        resolve(emp);
        return res.status(201).json({
            message:'employee created successfully',
            success:true
        });
        }
        catch(err){
            reject(err);
           return res.status(500).json({
                message:err.message,
                success:false
            })
        }
    })
    }

    module.exports = {
        getEmployees,
        createEmployee
    }