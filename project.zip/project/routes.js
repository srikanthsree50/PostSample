const express = require('express');
const router = express.Router();
const {getEmployees,createEmployee} = require('./controllers');

router.get('/',async (req,res) => {
    
await getEmployees(req,res)
});

router.post('/',async (req,res) => {
    await createEmployee(req,res);
    });

module.exports = router;