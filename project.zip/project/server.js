const joi = require('joi')
/////////////////////////////////////////////////////////////////
// const passcomplex = require('joi-password-complexity');
// const complexOptions = {
//     min:8,
//     max:34,
//     uppercase:1,
//     lowercase:1,
//     numeric:1,
//     symbol:1,
//     requirementCount:3
// }
// passcomplex(complexOptions).validate(password);


/////////////////////////////////////////////////////
const joiSchema = joi.object({
    fullname:joi.string(),
    firstname:joi.string(),
    lastname:joi.string(),
    name:joi.string(),
    age:joi.number().integer().min(1).max(80).required(),
    username:joi.string().alphanum().min(6).max(12).custom((value,helper) => {
        if(value.length<10)
        return helper.message('val should be greater than 10')
        return true;
        }),
    password:joi.string().regex(new RegExp("^[a-zA-Z0-9]{8,32}$")).required(),
    confirm_password:joi.ref('password'),
    token:joi.any(),
    card:joi.string().creditCard(),
    email:joi.string().email({
        minDomainSegments:2,
        tlds:{allow:['com','in']}
    }),
    backlogs:joi.array().items(
        joi.object({
            sub:joi.string(),
            marks:joi.number()
        })
    ).required(),
    type: joi.string().valid("user","admin").required(),
    salaryAge:joi.when("type",{
      is:"admin",
      then:joi.number().min(20).max(45),
      otherwise:joi.number().min(45).max(79)  
    })
})

.xor('fullname','firstname')
.and('firstname','lastname')

const payload = {
    firstname:'firstname',
    name:'srikanth',
    age:34,
    username:'sri123',
    password:'helLoi123',
    confirm_password:'helLoi123',
    token:'any',
    email:'email@email.us',
    backlogs:[{sub:'maths',marks:43}],
    type:'admin',
    salaryAge:56,

}
const {error , value} = joiSchema.validate(payload)


if(error){
    console.log(error.message)
}
console.log(value)