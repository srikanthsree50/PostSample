const port = process.env.PORT || 8080;
const express = require('express');
const { get } = require('http');
const joi = require('joi');
const app = express();
app.use(express.json())

const schema = joi.object({
    name:joi.string().min(6).max(32).required(),
    age:joi.number().min(1).max(80).required(),
    salary:joi.number().min(25000).required(),
    location:joi.string().min(6).max(16).required()
})

app.post('/',(req,res) => {
    const body = req.body
  const {error,value}  = schema.validate(body)
  if(error){
      res.status(400).send(error.message)
  }
    res.status(201).send(value)
})

app.listen(port,() => {
    console.log(`Server started Successfully on Port : ${port}`);
  })