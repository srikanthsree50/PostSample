const port = process.env.PORT || 8080;
const express = require('express');
const app = express();
const bodyParser = require('body-parser');

// const path = require('path');
// const cors = require('cors');

// const {connect} = require('mongoose')
// const Url = 'mongodb://localhost:27017/NodeDB';

// const empModel = require('./models')
// const empRouter = require('./routes')
 const {createEmployee,getEmployees}= require('./controllers')

app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended:true}));
// app.use('/',express.static(path.join(__dirname,'/public')))
// app.use(cors())
//app.use('/api/v1/employee/', empRouter);

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );

  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST"
  );
  next();
});

app.get('/' , async (req,res) => {
 await getEmployees(req,res);
})

app.post('/' , async (req,res) => {
  await createEmployee(req,res);
 })
 

app.listen(port,() => {
  console.log(`Server started Successfully on Port : ${port}`);
})

// app.use('/',(req,res,next) => {
//     if(req.method === 'get' || req.method === 'post'){
//         next()
//     }
//     return res.statusCode(403).send('access denied');
// })



// const startApp = async () => {
//     try{
//   await connect(Url, {
//   useFindAndModify: false,
//   useUnifiedTopology: true,
//   useNewUrlParser: true,
//   useCreateIndex: true
//   });
//   console.log('successfully connected to database...');
  
//   app.listen(port,() => {
//     console.log(`Server started Successfully on Port : ${port}`);
//   })
  
//     }
//     catch(err){
//   console.log(err);
//   startApp();
//     }
//   }
  
//   startApp();