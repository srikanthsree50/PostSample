
const getEmployees = async(req,res) => {
    try {
const employees = req.body;
if(employees){
return res.status(201).json({
    object:"list",
    data: employees,
    message:' employees fetched successfully...',
    success:true
});
}
return res.status(404).json({
message: 'employees not found ',
success:false
});
    }
    catch(err){
        return res.status(500).json({
            message:err.message,
            success:false
        })
    }
}

// const emp =
// {
//     _id:"asklakkjfhagjfdjajfdaajaj",
//     name:"srikanth",
//     salary: 354774,
//     location:"hyderabad"
// }

const createEmployee = async (req,res) => {
    return new Promise((resolve,reject) => {
        try{
            const emp = req.body;
        resolve(emp);
        return res.status(201).json({
            message:'employee created successfully',
            data:emp,
            success:true
        });
        }
        catch(err){
            reject(err);
           return res.status(500).json({
                message:err.message,
                success:false
            })
        }
    })
    }

    module.exports = {
        getEmployees,
        createEmployee
    }