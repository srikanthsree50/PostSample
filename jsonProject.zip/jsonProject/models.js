const mongoose = require('mongoose');

const {Schema , Model} = mongoose;

const employeeSchema = new Schema({
    id : {
        type:mongoose.Schema.types.objectId,
        required:true
    },
    name:{
        type: String,
        required :[true , 'please provide a valid employee name'],
        min:10,
        max:50
    },
    salary:{
        type: Number,
        required :[true , 'please provide salary'],
    },
    
    location:{
        type: String,
        required :[true , 'please provide location'],
    }
},{timestamps:true})


module.exports = mongoose.model('Employee',employeeSchema)