module.exports = {
    default: {
        import: ['features/**/*.js'],
      publishQuiet: true
    }
  };
  