class Greeter {
    sayHello() {
        return "hello";
    }
}
module.exports = Greeter;